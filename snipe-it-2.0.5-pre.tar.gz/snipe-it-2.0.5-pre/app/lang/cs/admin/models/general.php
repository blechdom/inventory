<?php

return array(

    'deleted'  					=> 'Model byl vymazán. <a href="/hardware/models/:model_id/restore">Klikněte sem pro jeho obnovení</a>.',
    'restore'                   => 'Obnovení Modelu',
	'show_mac_address'			=> 'Show MAC address field in assets in this model',
    'view_deleted'              => 'Zobrazit smazané',
    'view_models'               => 'Zobrazit Modely',

);
