<?php

return array(
    'about_consumables_title' 			=> 'About Consumables',
    'about_consumables_text'  			=> 'Consumables are anything purchased that will be used up over time. For example, printer ink or copier paper.',
    'consumable_name'                  => 'Consumable Name',
    'cost'				=> 'Purchase Cost',
    'create'                             => 'Create Consumable',
    'date'					=> 'Purchase Date',
    'order'					=> 'Order Number',
    'remaining' 			             => 'Remaining',
    'total' 			                 => 'Total',
    'update'                            => 'Update Consumable',
);
