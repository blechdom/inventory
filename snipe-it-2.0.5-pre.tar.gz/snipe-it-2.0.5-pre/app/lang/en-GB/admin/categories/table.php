<?php

return array(
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'parent'   					=> 'Parent',
    'require_acceptance'      	=> 'Acceptance',
    'title'      				=> 'Asset Category Name',

);
