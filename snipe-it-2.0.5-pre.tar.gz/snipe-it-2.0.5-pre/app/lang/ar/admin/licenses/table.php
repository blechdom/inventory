<?php

return array(

    'assigned_to'   	=> 'Assigned To',
    'checkout'   		=> 'In/Out',
    'id'      			=> 'ID',
    'license_email'   	=> 'License Email',
    'license_name'   	=> 'Licensed To',
    'purchase_date'   	=> 'Purchase Date',
    'purchased'   		=> 'Purchased',
    'seats'   			=> 'Seats',
    'hardware'   		=> 'Hardware',
    'serial'   			=> 'Serial',
    'title'      		=> 'License',

);
