<?php

return array(

    'asset_tag'   	=> 'Инвентарен номер',
    'asset_model'       => 'Модел',
    'book_value'  	=> 'Стойност',
    'change' 		=> 'Предоставяне',
    'checkout_date' => 'Дата на изписване',
    'checkoutto' 	=> 'Изписан',
    'diff' 			=> 'Разлика',
    'dl_csv' 		=> 'Сваляне на CSV',
    'eol' 			=> 'EOL',
    'id'      		=> 'ID',
    'location' 		=> 'Местоположение',
    'purchase_cost'	=> 'Стойност',
    'purchase_date'	=> 'Закупен',
    'serial'   		=> 'Сериен номер',
    'status'   		=> 'Статус',
    'title'      	=> 'Актив ',
    'days_without_acceptance' => 'Дни без да е предаден'

);
