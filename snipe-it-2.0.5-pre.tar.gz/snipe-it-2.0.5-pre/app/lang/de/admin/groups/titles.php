<?php

return array(

    'group_management' 	 	=> 'Gruppenverwaltung',
    'create_group' 	 		=> 'Neue Gruppe erstellen',
    'edit_group' 	 		=> 'Gruppe editieren',
    'group_name' 	 		=> 'Gruppenname',
    'group_admin' 	 		=> 'Gruppenadministrator',
    'allow' 	 			=> 'Zulassen',
    'deny' 	 				=> 'Ablehnen',

);
