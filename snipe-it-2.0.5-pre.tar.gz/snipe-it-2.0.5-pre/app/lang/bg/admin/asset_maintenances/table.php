<?php

    return [
        'title'         => 'Поддръжка на активи',
        'asset_name'    => 'Актив',
        'supplier_name' => 'Доставчик',
        'is_warranty'   => 'Гаранция',
        'dl_csv'        => 'Сваляне на CSV'
    ];
