<?php

return array(
	'eula_text'      			=> 'EULA',
    'id'      					=> 'الرقم',
    'parent'   					=> 'التصنيف الأب',
    'require_acceptance'      	=> 'Acceptance',
    'title'      				=> 'اسم التصنيف',

);
