<?php

return array(
    'about_asset_depreciations'  			=> 'عن استهلاك الأصول',
    'about_depreciations'  					=> 'يمكنك ضبط قيمة إستهلاك الأصول لخفض الأصول على أساس القسط الثابت للاستهلاك.',
    'asset_depreciations'  					=> 'استهلاك الأصول',
    'create_depreciation'  					=> 'إنشاء الاستهلاك',
    'depreciation_name'  					=> 'اسم الاستهلاك',
    'number_of_months'  					=> 'عدد الأشهر',
    'update_depreciation'  					=> 'تحديث الاستهلاك',

);
