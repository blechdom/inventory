<?php

return array(

    'create'				=> 'Asset Model erstellen',
    'created_at' 			=> 'Erstellt am',
    'eol'	 				=> 'EOL',
    'modelnumber'   		=> 'Modellnummer',
    'name'      			=> 'Asset Modellname',
    'numassets' 			=> 'Assets',
    'title'					=> 'Asset Modelle',
    'update'				=> 'Asset Modell aktualisieren',
    'view'					=> 'Asset Modell ansehen',
    'update'				=> 'Asset Modell aktualisieren',
    'clone'				=> 'Modell duplizieren',
    'edit'				=> 'Modell bearbeiten',
);
