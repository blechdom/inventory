<?php

return array(

    'actions'	 	=> 'Handlinger',
    'action' 		=> 'Handling',
    'by'      		=> 'Af',
    'item' 			=> 'Item',

);
