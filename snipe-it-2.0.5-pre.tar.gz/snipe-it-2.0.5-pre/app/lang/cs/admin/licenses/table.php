<?php

return array(

    'assigned_to'   	=> 'Přiděleno',
    'checkout'   		=> 'Stav',
    'id'      			=> 'ID',
    'license_email'   	=> 'License Email',
    'license_name'   	=> 'Registrováno na',
    'purchase_date'   	=> 'Pořízeno',
    'purchased'   		=> 'Zakoupeno',
    'seats'   			=> 'Seats',
    'hardware'   		=> 'Hardware',
    'serial'   			=> 'Sériové číslo',
    'title'      		=> 'Licence',

);
