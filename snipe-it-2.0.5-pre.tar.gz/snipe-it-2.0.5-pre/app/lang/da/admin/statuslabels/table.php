<?php

return array(
    'about'      	=> 'Om status labels',
    'archived'      	=> 'Archived',
    'create'      	=> 'Opret status label',
    'deployable'      	=> 'Deployable',
    'info'      	=> 'Status labels are used to describe the various states your assets could be in. They may be out for repair, lost/stolen, etc. You can create new status labels for deployable, pending and archived assets.',
    'name'      	=> 'Status navn',
    'pending'      	=> 'Pending',
    'status_type'   => 'Status Type',
    'title'      	=> 'Status labels',
    'undeployable'  => 'Undeployable',
    'update'      	=> 'Opdater status label',
);
