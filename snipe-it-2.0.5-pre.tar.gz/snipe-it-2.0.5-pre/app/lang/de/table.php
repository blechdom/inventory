<?php

return array(

    'actions'	 	=> 'Aktionen',
    'action' 		=> 'Aktion',
    'by'      		=> 'Von',
    'item' 			=> 'Gegenstand',

);
