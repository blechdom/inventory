<?php

return array(
	'dl_csv'      				=> 'Download CSV',
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'require_acceptance'      	=> 'Přijetí',
    'title'      				=> 'Název příslušenství',


);
