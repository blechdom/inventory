<?php

return array(

    'id'         => 'الرقم',
    'name'       => 'الإسم',
    'users'      => 'عدد المستخدمين',

);
