<?php

    return [
        'asset_maintenance_type' => 'Typ des Wartungsvertrages',
        'title'                  => 'Artikelbezeichnung',
        'start_date'             => 'Startdatum',
        'completion_date'        => 'Fertigstellungstermin',
        'cost'                   => 'Kosten (Netto wenn keine Steuer)',
        'is_warranty'            => 'Nachbesserungsarbeiten',
        'asset_maintenance_time' => 'Wartungsvertrag (in Tagen)',
        'notes'                  => 'Anmerkungen',
        'update'                 => 'Wartungsvertrag überarbeiten',
        'create'                 => 'Wartungsvertrag erstellen'
    ];
