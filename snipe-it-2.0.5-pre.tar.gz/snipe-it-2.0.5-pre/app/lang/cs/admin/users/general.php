<?php


return array(

    'assets_user'       => 'Assets assigned to :name',
    'clone'             => 'Duplikuj uživatele',
    'contact_user'      => 'Kontakt na :name',
    'edit'              => 'Upravit uživatele',
    'filetype_info'     => 'Povolené přílohy: png, gif, jpg, jpeg, doc, docx, pdf, txt, zip, and rar.',
    'history_user'      => 'Historie:',
    'last_login'        => 'Poslední přihlášení',
    'ldap_config_text'  => 'LDAP configuration settings can be found in the app/config folder in a file called ldap.php. The selected location will be set for all imported users. You will need to have at least one location set to use this feature.',
    'ldap_text'         => 'Connect to LDAP and create users.  Passwords will be auto-generated.',
    'software_user'     => 'Software vydaný pro :name',
    'view_user'         => 'Zobraz uživatele',
    'usercsv'           => 'CSV soubor',
    );
