<?php

    return [
        'asset_maintenance_type' => 'Maintenance Type',
        'title'                  => 'Title',
        'start_date'             => 'Started',
        'completion_date'        => 'Completed',
        'cost'                   => 'Cost',
        'is_warranty'            => 'Warranty Improvement',
        'asset_maintenance_time' => 'Days',
        'notes'                  => 'Notes',
        'update'                 => 'Update',
        'create'                 => 'Create'
    ];
