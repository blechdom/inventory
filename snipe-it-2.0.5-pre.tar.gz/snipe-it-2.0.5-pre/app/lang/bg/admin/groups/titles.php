<?php

return array(

    'group_management' 	 	=> 'Управление на групи',
    'create_group' 	 		=> 'Нова група',
    'edit_group' 	 		=> 'Редакция на група',
    'group_name' 	 		=> 'Име на група',
    'group_admin' 	 		=> 'Администратор на група',
    'allow' 	 			=> 'Разрешаване',
    'deny' 	 				=> 'Отказ',

);
