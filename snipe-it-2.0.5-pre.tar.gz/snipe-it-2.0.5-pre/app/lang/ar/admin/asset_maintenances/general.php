<?php

    return [
        'asset_maintenances' => 'Asset Maintenances',
        'edit'               => 'Edit Asset Maintenance',
        'delete'             => 'Delete Asset Maintenance',
        'view'               => 'View Asset Maintenance Details',
        'repair'             => 'Repair',
        'maintenance'        => 'Maintenance',
        'upgrade'            => 'Upgrade'
    ];
