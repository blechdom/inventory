<?php

return array(


    'update' => array(
        'error'                 => 'Vyskytla se chyba při aktualizaci. ',
        'success'               => 'Nastavení úspěšně uloženo.'
    ),
    'backup' => array(
        'delete_confirm'        => 'Are you sure you would like to delete this backup file? This action cannot be undone. ',
        'file_deleted'          => 'The backup file was successfully deleted. ',
        'generated'             => 'A new backup file was successfully created.',
        'file_not_found'        => 'That backup file could not be found on the server.',
    ),

);
