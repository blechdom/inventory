<?php

return array(
	'dl_csv'      				=> 'Download CSV',
	'eula_text'      			=> 'اتفاقية ترخيص المستخدم',
    'id'      					=> 'رقم المعرف',
    'require_acceptance'      	=> 'القبول',
    'title'      				=> 'اسم الملحق',


);
