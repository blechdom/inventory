<?php

    return [
        'title'         => 'Asset Maintenance',
        'asset_name'    => 'Asset Name',
        'supplier_name' => 'Supplier Name',
        'is_warranty'   => 'Warranty',
        'dl_csv'        => 'Download CSV'
    ];
