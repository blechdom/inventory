<?php

return array(
    'error'   => 'Трябва да изберете поне една опция.'
);
