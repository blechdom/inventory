<?php

return array(

    'checkin'  					=> 'Lizenzaktivierung zurücknehmen',
    'checkout_history'  		=> 'Zuweisungsverlauf',
    'checkout'  				=> 'Lizenzaktivierung herausgeben',
    'edit'  					=> 'Edit User',
    'filetype_info'				=> 'Erlaubte Dateitypen sind png, gif, jpg, jpeg, doc, docx, pdf, txt, zip, und rar.',
    'clone'  					=> 'Clone User',
    'history_for'  				=> 'Verlauf für ',
    'in_out'  					=> 'Zurücknehmen/Herausgeben',
    'info'  					=> 'Lizenzinfo',
    'license_seats'  			=> 'Lizenzaktivierungen',
    'seat'  					=> 'Lizenz',
    'seats'  					=> 'Verfügbare Lizenzen',
    'software_licenses'  		=> 'Software Lizenzen',
    'user'  					=> 'Nutzer',
    'view'  					=> 'Lizenz ansehen',
);
