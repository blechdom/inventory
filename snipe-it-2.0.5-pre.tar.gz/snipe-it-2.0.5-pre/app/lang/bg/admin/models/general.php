<?php

return array(

    'deleted'  					=> 'Моделът беше изтрит. <a href="/hardware/models/:model_id/restore">Възстановяване</a>.',
    'restore'                   => 'Възстановяване на модел',
	'show_mac_address'			=> 'Визуализиране на поле за MAC адрес в активите за този модел',
    'view_deleted'              => 'Преглед на изтритите',
    'view_models'               => 'Преглед на моделите',

);
