<?php

return array(
    'about_asset_depreciations'  			=> 'Omkring Aktiv Afskrivninger',
    'about_depreciations'  					=> 'Du kan sætte aktiv afskrivninger til at afskrive aktiver baseret på lineære afskrivninger.',
    'asset_depreciations'  					=> 'Aktiv Afskrivninger',
    'create_depreciation'  					=> 'Opret Afskrivning',
    'depreciation_name'  					=> 'Afskrivningnavn',
    'number_of_months'  					=> 'Antal måneder',
    'update_depreciation'  					=> 'Opdater Afskrivning',

);
