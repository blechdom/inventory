<?php

return array(

    'id'      => 'الرقم',
    'months'   => 'أشهر',
    'term'   => 'المدة',
    'title'      => 'الإسم ',

);
