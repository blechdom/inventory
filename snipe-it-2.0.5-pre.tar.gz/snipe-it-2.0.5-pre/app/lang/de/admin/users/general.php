<?php


return array(

    'assets_user'       => 'Assets zugewiesen an :name',
    'clone'             => 'Benutzer kopieren',
    'contact_user'      => 'Kontakt :name',
    'edit'              => 'Benutzer bearbeiten',
    'filetype_info'     => 'Erlaubte Dateitypen sind png, gif, jpg, jpeg, doc, docx, pdf, txt, zip, und rar.',
    'history_user'      => 'Historie von :name',
    'last_login'        => 'Letzte Anmeldung',
    'ldap_config_text'  => 'LDAP Einstellungen können im app/config Ordner in der Datei ldap.php gefunden werden. Der eingestellte Standort wird für alle Importierten Benutzer gesetzt. Du musst mindestens einen Standort gesetzt haben, um diese Funktion zu benutzten.',
    'ldap_text'         => 'Mit LDAP verbinden und Benutzer anlegen. Passwörter werden automatisch generiert.',
    'software_user'     => 'Software herausgegeben an :name',
    'view_user'         => 'Benutze :name ansehen',
    'usercsv'           => 'CSV Datei',
    );
