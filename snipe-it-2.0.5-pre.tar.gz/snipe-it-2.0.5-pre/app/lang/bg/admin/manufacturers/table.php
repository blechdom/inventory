<?php

return array(

    'asset_manufacturers'	=> 'Производители',
    'create'				=> 'Създаване на производител',
    'id'   					=> 'ID',
    'name'      			=> 'Име на производител',
    'update'				=> 'Обновяване на производител',

);
