<?php

return array(

    'group_management' 	 	=> 'إدارة المجموعة',
    'create_group' 	 		=> 'إنشاء مجموعة جديدة',
    'edit_group' 	 		=> 'تعديل المجموعة',
    'group_name' 	 		=> 'اسم المجموعة',
    'group_admin' 	 		=> 'إدارة المجموعة',
    'allow' 	 			=> 'سماح',
    'deny' 	 				=> 'رفض',

);
