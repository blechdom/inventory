<?php

return array(
	'dl_csv'      				=> 'CSV Herunterladen',
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'require_acceptance'      	=> 'Zustimmung',
    'title'      				=> 'Zubehör Name',


);
