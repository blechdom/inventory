<?php

return array(

    'id'         => 'ID',
    'name'       => 'Име',
    'users'      => 'Брой потребители',

);
