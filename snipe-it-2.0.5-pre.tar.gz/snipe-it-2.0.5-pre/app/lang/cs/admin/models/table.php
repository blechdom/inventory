<?php

return array(

    'create'				=> 'Create Asset Model',
    'created_at' 			=> 'Vytvořeno',
    'eol'	 				=> 'KŽ',
    'modelnumber'   		=> 'Modelová řada',
    'name'      			=> 'Asset Model Name',
    'numassets' 			=> 'Počet',
    'title'					=> 'Model',
    'update'				=> 'Update Asset Model',
    'view'					=> 'View Asset Model',
    'update'				=> 'Update Asset Model',
    'clone'				=> 'Kopíruj modelovou řadu',
    'edit'				=> 'Edituj model',
);
