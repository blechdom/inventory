<?php

return array(

    'asset_tag'   	=> 'Asset Tag',
    'asset_model'       => 'Modell',
    'book_value'  	=> 'Wert',
    'change' 		=> 'Zurücknehmen/Herausgeben',
    'checkout_date' => 'Herausgabedatum',
    'checkoutto' 	=> 'Herausgegeben',
    'diff' 			=> 'Differenz',
    'dl_csv' 		=> 'CSV Herunterladen',
    'eol' 			=> 'EOL',
    'id'      		=> 'ID',
    'location' 		=> 'Ort',
    'purchase_cost'	=> 'Kosten',
    'purchase_date'	=> 'Gekauft',
    'serial'   		=> 'Seriennummer',
    'status'   		=> 'Status',
    'title'      	=> 'Asset ',
    'days_without_acceptance' => 'Tage ohne Akzeptierung'

);
