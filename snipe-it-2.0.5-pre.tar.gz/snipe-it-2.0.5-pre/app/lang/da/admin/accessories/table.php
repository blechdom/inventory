<?php

return array(
	'dl_csv'      				=> 'Download CSV',
	'eula_text'      			=> 'Slutbrugerlicens',
    'id'      					=> 'ID',
    'require_acceptance'      	=> 'Accept',
    'title'      				=> 'Tilbehør Navn',


);
