<?php

return array(

    'create'				=> 'Create Asset Model',
    'created_at' 			=> 'Created at',
    'eol'	 				=> 'EOL',
    'modelnumber'   		=> 'Model No.',
    'name'      			=> 'Asset Model Name',
    'numassets' 			=> 'Assets',
    'title'					=> 'Asset Models',
    'update'				=> 'Update Asset Model',
    'view'					=> 'View Asset Model',
    'update'				=> 'Update Asset Model',
    'clone'				=> 'Clone Model',
    'edit'				=> 'Edit Model',
);
