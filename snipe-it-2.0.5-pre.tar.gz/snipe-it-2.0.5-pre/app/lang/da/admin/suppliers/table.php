<?php

return array(
    'address'               => 'Supplier Address',
    'assets'                => 'Assets',
    'city'                  => 'By',
    'contact'               => 'Contact Name',
    'country'               => 'Country',
    'create'                => 'Create Supplier',
    'email'                 => 'Email',
    'fax'                   => 'Fax',
    'id'                    => 'ID',
    'licenses'              => 'Licenses',
    'name'                  => 'Supplier Name',
    'notes'                 => 'Notes',
    'phone'                 => 'Phone',
    'state'                 => 'State',
    'suppliers'             => 'Suppliers',
    'update'                => 'Update Supplier',
    'url'                   => 'URL',
    'view'                  => 'View Supplier',
    'view_assets_for'       => 'View Assets for',
    'zip'                   => 'Postal Code',

);
