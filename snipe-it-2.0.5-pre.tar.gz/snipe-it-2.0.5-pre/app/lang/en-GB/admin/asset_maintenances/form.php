<?php

    return [
        'asset_maintenance_type' => 'Asset Maintenance Type',
        'title'                  => 'Title',
        'start_date'             => 'Start Date',
        'completion_date'        => 'Completion Date',
        'cost'                   => 'Cost',
        'is_warranty'            => 'Warranty Improvement',
        'asset_maintenance_time' => 'Asset Maintenance Time (in days)',
        'notes'                  => 'Notes',
        'update'                 => 'Update Asset Maintenance',
        'create'                 => 'Create Asset Maintenance'
    ];
