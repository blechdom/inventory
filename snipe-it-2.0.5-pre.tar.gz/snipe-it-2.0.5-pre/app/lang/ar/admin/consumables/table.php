<?php

return array(
    'title'      				=> 'Consumable Name',
);
