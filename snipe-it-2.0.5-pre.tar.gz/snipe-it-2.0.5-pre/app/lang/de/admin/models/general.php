<?php

return array(

    'deleted'  					=> 'Dieses Modell wurde gelöscht.<a href="/hardware/models/:model_id/restore">klicken Sie hier um es Wiederzuherstellen</a>.',
    'restore'                   => 'Modell wiederherstellen',
	'show_mac_address'			=> 'MAC Adressen Feld anzeigen für Assets mit diesses Modell',
    'view_deleted'              => 'Gelöschte anzeigen',
    'view_models'               => 'Modelle anzeigen',

);
