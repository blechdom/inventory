<?php

return array(
    'about'      	=> 'Info Statusbezeichnung',
    'archived'      	=> 'Archiviert',
    'create'      	=> 'Statusbezeichnung erstellen',
    'deployable'      	=> 'Einsetzbar',
    'info'      	=> 'Status Label werden eingesetzt um diverse Stati Ihrer Assets zu beschreiben. Diese können zB. in Reparatur sein, Gestohlen oder Verlohren worden sein. Sie können neue Status Labels für Einsetzbare, Unerledigte und Archivierte Assets erstellen.',
    'name'      	=> 'Statusname',
    'pending'      	=> 'Unerledigt',
    'status_type'   => 'Statustyp',
    'title'      	=> 'Statusbezeichnungen',
    'undeployable'  => 'nicht Einsetzbar',
    'update'      	=> 'Statusbezeichnung bearbeiten',
);
