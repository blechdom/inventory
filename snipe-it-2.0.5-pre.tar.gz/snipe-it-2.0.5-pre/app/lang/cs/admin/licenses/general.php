<?php

return array(

    'checkin'  					=> 'Checkin License Seat',
    'checkout_history'  		=> 'Historie',
    'checkout'  				=> 'Checkout License Seat',
    'edit'  					=> 'Uprav licenci',
    'filetype_info'				=> 'Allowed filetypes are png, gif, jpg, jpeg, doc, docx, pdf, txt, zip, and rar.',
    'clone'  					=> 'Duplikovat licenci',
    'history_for'  				=> 'Historie uživatele ',
    'in_out'  					=> 'Stav',
    'info'  					=> 'Informace o licenci',
    'license_seats'  			=> 'License Seats',
    'seat'  					=> 'Seat',
    'seats'  					=> 'Počet licencí',
    'software_licenses'  		=> 'Softwarové licence',
    'user'  					=> 'Uživatel',
    'view'  					=> 'Ukaž licenci',
);
