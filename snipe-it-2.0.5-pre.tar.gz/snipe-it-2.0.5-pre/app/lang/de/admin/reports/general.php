<?php

return array(
    'info'   => 'Wähle eine Option für deinen Asset Bericht.'
);
