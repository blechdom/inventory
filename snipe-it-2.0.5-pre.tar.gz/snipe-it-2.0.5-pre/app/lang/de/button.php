<?php

return array(

    'actions' 	=> 'Aktionen',
    'add'    	=> 'Hinzufügen',
    'cancel'    => 'Abbrechen',
    'delete'  	=> 'Löschen',
    'edit'    	=> 'Bearbeiten',
    'restore' 	=> 'Wiederherstellen',
    'request'   => 'Anfragen',
    'submit'  	=> 'Abschicken',
    'upload'    => 'Hochladen',

);
