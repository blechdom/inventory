<?php

return array(
    'assets_rtd'		=> 'Assets RTD',
    'assets_checkedout'		=> 'Assets Assigned',
    'id'      		=> 'ID',
    'city'   		=> 'Град',
    'state'   		=> 'Област',
    'country'   	=> 'Държава',
    'create'		=> 'Създаване на местоположение',
    'update'		=> 'Обновяване на местоположение',
    'name'			=> 'Местоположение',
    'address'		=> 'Aдрес',
    'zip'			=> 'Пощенски код',
    'locations'		=> 'Местоположения',
    'parent'		=> 'Присъединено към',
    'currency'  	=> 'Валута на местоположението',
);
