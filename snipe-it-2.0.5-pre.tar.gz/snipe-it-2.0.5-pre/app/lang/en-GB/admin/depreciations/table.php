<?php

return array(

    'id'      => 'ID',
    'months'   => 'Months',
    'term'   => 'Term',
    'title'      => 'Name ',

);
