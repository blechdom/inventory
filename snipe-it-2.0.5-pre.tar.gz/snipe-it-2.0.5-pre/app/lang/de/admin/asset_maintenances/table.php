<?php

    return [
        'title'         => 'Wartungsverträge',
        'asset_name'    => 'Name des Gegenstandes',
        'supplier_name' => 'Hersteller',
        'is_warranty'   => 'Garantie',
        'dl_csv'        => 'Als CSV herunterladen'
    ];
