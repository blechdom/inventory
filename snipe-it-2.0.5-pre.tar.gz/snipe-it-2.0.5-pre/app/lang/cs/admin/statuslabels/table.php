<?php

return array(
    'about'      	=> 'O označení stavu',
    'archived'      	=> 'Archivováno',
    'create'      	=> 'Vytvořit označení stavu',
    'deployable'      	=> 'Připraveno k nasazení',
    'info'      	=> 'Označení stavu se používá k popisu různých stavů majetku. Můžou být v opravě, ztracení atd. Lze vytvořit nové stavy pro další možné stavy.',
    'name'      	=> 'Název stavu',
    'pending'      	=> 'Probíhající',
    'status_type'   => 'Typ stavu',
    'title'      	=> 'Označení stavu',
    'undeployable'  => 'Nemožné připravit',
    'update'      	=> 'Upravit označení stavu',
);
