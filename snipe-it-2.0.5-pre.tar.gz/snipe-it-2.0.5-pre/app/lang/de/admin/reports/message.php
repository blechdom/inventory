<?php

return array(
    'error'   => 'Sie müssen eine Option auswählen.'
);
