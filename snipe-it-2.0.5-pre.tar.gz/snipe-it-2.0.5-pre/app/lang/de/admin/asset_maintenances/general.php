<?php

    return [
        'asset_maintenances' => 'Wartungsverträge',
        'edit'               => 'Wartungsvertrag bearbeiten',
        'delete'             => 'Wartungsvertrag löschen',
        'view'               => 'Details des Wartungsvertrages anzeigen',
        'repair'             => 'Reparatur',
        'maintenance'        => 'Wartung',
        'upgrade'            => 'Upgrade'
    ];
