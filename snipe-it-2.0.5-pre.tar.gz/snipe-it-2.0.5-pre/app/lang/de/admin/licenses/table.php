<?php

return array(

    'assigned_to'   	=> 'Zugewiesen an',
    'checkout'   		=> 'Zurücknehmen/Herausgeben',
    'id'      			=> 'ID',
    'license_email'   	=> 'Lizenziert für Email',
    'license_name'   	=> 'Lizenziert für',
    'purchase_date'   	=> 'Kaufdatum',
    'purchased'   		=> 'Gekauft',
    'seats'   			=> 'Anzahl Aktivierungen',
    'hardware'   		=> 'Hardware',
    'serial'   			=> 'Seriennummer',
    'title'      		=> 'Name der Asset-Kategorie',

);
