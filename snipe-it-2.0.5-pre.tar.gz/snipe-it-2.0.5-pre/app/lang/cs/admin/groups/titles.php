<?php

return array(

    'group_management' 	 	=> 'Správa skupin',
    'create_group' 	 		=> 'Vytvořit novou skupinu',
    'edit_group' 	 		=> 'Upravit skupinu',
    'group_name' 	 		=> 'Název skupiny',
    'group_admin' 	 		=> 'Správce skupiny',
    'allow' 	 			=> 'Povolit',
    'deny' 	 				=> 'Zakázat',

);
