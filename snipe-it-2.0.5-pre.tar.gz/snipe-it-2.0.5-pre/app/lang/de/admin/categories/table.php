<?php

return array(
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'parent'   					=> 'Übergeordneten',
    'require_acceptance'      	=> 'Zustimmung',
    'title'      				=> 'Posten Kategorie Name',

);
