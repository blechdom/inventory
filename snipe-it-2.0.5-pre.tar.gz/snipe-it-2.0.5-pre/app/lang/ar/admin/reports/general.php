<?php

return array(
    'info'   => 'Select the options you want for your asset report.'
);
