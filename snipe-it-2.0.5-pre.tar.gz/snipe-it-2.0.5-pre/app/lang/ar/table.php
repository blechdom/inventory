<?php

return array(

    'actions'	 	=> 'الإجراءات',
    'action' 		=> 'Action',
    'by'      		=> 'By',
    'item' 			=> 'Item',

);
