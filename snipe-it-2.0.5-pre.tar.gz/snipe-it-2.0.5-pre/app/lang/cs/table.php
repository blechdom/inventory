<?php

return array(

    'actions'	 	=> 'Akce',
    'action' 		=> 'Akce',
    'by'      		=> 'Vytvořil',
    'item' 			=> 'Položka',

);
