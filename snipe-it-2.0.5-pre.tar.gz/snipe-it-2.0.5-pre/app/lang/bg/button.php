<?php

return array(

    'actions' 	=> 'Действия',
    'add'    	=> 'Добави нов',
    'cancel'    => 'Отказ',
    'delete'  	=> 'Изтриване',
    'edit'    	=> 'Редакция',
    'restore' 	=> 'Възстановяване',
    'request'   => 'Заявка',
    'submit'  	=> 'Потвърди',
    'upload'    => 'Качване',

);
