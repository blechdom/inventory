<?php

return array(
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'parent'   					=> 'Nadřazená složka',
    'require_acceptance'      	=> 'Acceptance',
    'title'      				=> 'Jméno kategorie majetku',

);
