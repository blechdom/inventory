<?php

return array(

    'id'      => 'ID',
    'months'   => 'Měsíců',
    'term'   => 'Podmínka',
    'title'      => 'Název ',

);
