<?php

return array(

    'id'         => 'Id',
    'name'       => 'Name',
    'users'      => '# von Benutzern',

);
