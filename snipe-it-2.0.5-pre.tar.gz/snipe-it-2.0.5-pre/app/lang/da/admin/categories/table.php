<?php

return array(
	'eula_text'      			=> 'Slutbrugerlicens',
    'id'      					=> 'ID',
    'parent'   					=> 'Forælder',
    'require_acceptance'      	=> 'Accept',
    'title'      				=> 'Aktiv Kategorinavn',

);
