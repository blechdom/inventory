<?php

return array(

    'id'      => 'ID',
    'months'   => 'Monate',
    'term'   => 'Laufzeit',
    'title'      => 'Name ',

);
