<?php
return array(
	'path' => 'app/storage/dumps/',

	'mysql' => array(
		'dump_command_path' => '',
		'restore_command_path' => '',
	),

	's3' => array(
		'path' => ''
	),

    'compress' => false,
);
