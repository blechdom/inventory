<?php

return array(

    'actions' 	=> 'Akce',
    'add'    	=> 'Přidej nový',
    'cancel'    => 'Zrušit',
    'delete'  	=> 'Smazat',
    'edit'    	=> 'Upravit',
    'restore' 	=> 'Obnovit',
    'request'   => 'Request',
    'submit'  	=> 'Odeslat',
    'upload'    => 'Nahrát',

);
