<?php

return array(

    'id'      => 'ID',
    'months'   => 'Måneder',
    'term'   => 'Term',
    'title'      => 'Navn ',

);
