<?php

return array(

    'asset_tag'   	=> 'Asset Tag',
    'asset_model'       => 'Model',
    'book_value'  	=> 'Value',
    'change' 		=> 'In/Out',
    'checkout_date' => 'Checkout Date',
    'checkoutto' 	=> 'Checked Out',
    'diff' 			=> 'Diff',
    'dl_csv' 		=> 'Download CSV',
    'eol' 			=> 'EOL',
    'id'      		=> 'ID',
    'location' 		=> 'Location',
    'purchase_cost'	=> 'Cost',
    'purchase_date'	=> 'Purchased',
    'serial'   		=> 'Serial',
    'status'   		=> 'Status',
    'title'      	=> 'Asset ',
    'days_without_acceptance' => 'Days Without Acceptance'

);
