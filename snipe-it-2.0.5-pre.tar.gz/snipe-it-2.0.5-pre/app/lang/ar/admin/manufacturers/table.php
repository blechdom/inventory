<?php

return array(

    'asset_manufacturers'	=> 'Asset Manufacturers',
    'create'				=> 'Create Manufacturer',
    'id'   					=> 'ID',
    'name'      			=> 'Manufacturer Name',
    'update'				=> 'Update Manufacturer',

);
