<?php

return array(
	'dl_csv'      				=> 'Сваляне на CSV',
	'eula_text'      			=> 'EULA',
    'id'      					=> 'ID',
    'require_acceptance'      	=> 'Утвърждаване',
    'title'      				=> 'Аксесоар',


);
