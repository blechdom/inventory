<?php

    return [
        'asset_maintenance_type' => 'Тип на поддръжка на актив',
        'title'                  => 'Заглавие',
        'start_date'             => 'Начална дата',
        'completion_date'        => 'Крайна дата',
        'cost'                   => 'Стойност',
        'is_warranty'            => 'Подобрение на гаранцията',
        'asset_maintenance_time' => 'Време за поддръжка на актив (в дни)',
        'notes'                  => 'Бележки',
        'update'                 => 'Редакция на поддръжка на актив',
        'create'                 => 'Създаване на поддръжка на актив'
    ];
