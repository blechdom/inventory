<?php

return array(
    'error'   => 'You must select at least ONE option.'
);
