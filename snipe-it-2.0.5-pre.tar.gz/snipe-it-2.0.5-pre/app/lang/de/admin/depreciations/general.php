<?php

return array(
    'about_asset_depreciations'  			=> 'Über Asset-Abschreibungen',
    'about_depreciations'  					=> 'Sie können Asset-Abschreibungen einrichten, um Assets linear abzuschreiben.',
    'asset_depreciations'  					=> 'Asset-Abschreibungen',
    'create_depreciation'  					=> 'Abschreibung erstellen',
    'depreciation_name'  					=> 'AfA-Name',
    'number_of_months'  					=> 'Anzahl der Monate',
    'update_depreciation'  					=> 'Abschreibung aktualisieren',

);
