<?php

return array(
    'address'               => 'Lieferantenadressen',
    'assets'                => 'Assets',
    'city'                  => 'Stadt',
    'contact'               => 'Kontakt',
    'country'               => 'Land',
    'create'                => 'Lieferanten erstellen',
    'email'                 => 'Email',
    'fax'                   => 'Fax',
    'id'                    => 'ID',
    'licenses'              => 'Lizenzen',
    'name'                  => 'Lieferantenname',
    'notes'                 => 'Notizen',
    'phone'                 => 'Telefonnummer',
    'state'                 => 'Bundesland',
    'suppliers'             => 'Lieferanten',
    'update'                => 'Lieferanten bearbeiten',
    'url'                   => 'URL',
    'view'                  => 'Lieferanten ansehen',
    'view_assets_for'       => 'Assets anschauen von',
    'zip'                   => 'Postleitzahl',

);
