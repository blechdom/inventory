<?php
return array (
  'app_version' => 'v2.0-394',
  'hash_version' => 'v2.0-394-g14ba5a3',
);