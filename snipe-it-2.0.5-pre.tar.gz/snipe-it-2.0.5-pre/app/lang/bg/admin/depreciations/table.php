<?php

return array(

    'id'      => 'ID',
    'months'   => 'Месеци',
    'term'   => 'Срок',
    'title'      => 'Име',

);
