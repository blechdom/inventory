<?php

return array(

    'group_management' 	 	=> 'Gruppehåndtering',
    'create_group' 	 		=> 'Opret Ny Gruppe',
    'edit_group' 	 		=> 'Rediger Gruppe',
    'group_name' 	 		=> 'Gruppenavn',
    'group_admin' 	 		=> 'Gruppeadministrator',
    'allow' 	 			=> 'Tillad',
    'deny' 	 				=> 'Afvis',

);
