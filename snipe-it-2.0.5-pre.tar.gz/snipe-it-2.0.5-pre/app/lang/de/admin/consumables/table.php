<?php

return array(
    'title'      				=> 'Name des Verbrauchsmaterials',
);
