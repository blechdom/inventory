<?php

    return [
        'title'         => 'Asset Maintenance',
        'asset_name'    => 'Asset',
        'supplier_name' => 'Supplier',
        'is_warranty'   => 'Warranty',
        'dl_csv'        => 'Download CSV'
    ];
