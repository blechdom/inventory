<?php

return array(
    'about_consumables_title' 			=> 'Details Verbrauchsmaterialien',
    'about_consumables_text'  			=> 'Verbrauchsmaterialien sind alle Dinge, die gekauft und mit der Zeit aufgebraucht werden, wie z.B. Druckerpatronen oder Kopierpapier.',
    'consumable_name'                  => 'Name des Verbrauchsmaterials',
    'cost'				=> 'Purchase Cost',
    'create'                             => 'Verbrauchsmaterial erstellen',
    'date'					=> 'Purchase Date',
    'order'					=> 'Order Number',
    'remaining' 			             => 'übrig',
    'total' 			                 => 'Gesamt',
    'update'                            => 'Verbrauchsmaterial überarbeiten',
);
