<?php

    return [
        'asset_maintenance_type' => 'Maintenance Type',
        'title'                  => 'Title',
        'start_date'             => 'Začátek',
        'completion_date'        => 'Completed',
        'cost'                   => 'Cena',
        'is_warranty'            => 'Warranty Improvement',
        'asset_maintenance_time' => 'Days',
        'notes'                  => 'Poznámky',
        'update'                 => 'Update',
        'create'                 => 'Create'
    ];
