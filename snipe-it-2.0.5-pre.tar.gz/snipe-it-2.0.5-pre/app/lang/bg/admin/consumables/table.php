<?php

return array(
    'title'      				=> 'Консуматив',
);
