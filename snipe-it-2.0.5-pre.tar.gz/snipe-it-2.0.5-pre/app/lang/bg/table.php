<?php

return array(

    'actions'	 	=> 'Действия',
    'action' 		=> 'Действие',
    'by'      		=> 'От',
    'item' 			=> 'Информация',

);
