<?php

    return [
        'title'         => 'Asset Maintenance',
        'asset_name'    => 'Název majetku',
        'supplier_name' => 'Dodavatel',
        'is_warranty'   => 'Záruka',
        'dl_csv'        => 'Stáhnout CSV'
    ];
