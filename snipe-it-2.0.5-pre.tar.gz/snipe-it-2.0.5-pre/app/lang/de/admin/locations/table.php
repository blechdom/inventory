<?php

return array(
    'assets_rtd'		=> 'Assets RTD',
    'assets_checkedout'		=> 'Assets Assigned',
    'id'      		=> 'ID',
    'city'   		=> 'Stadt',
    'state'   		=> 'Bundesland',
    'country'   	=> 'Land',
    'create'		=> 'Standort erstellen',
    'update'		=> 'Standort aktualisieren',
    'name'			=> 'Standortname',
    'address'		=> 'Adresse',
    'zip'			=> 'Postleitzahl',
    'locations'		=> 'Standorte',
    'parent'		=> 'Hauptkategorie',
    'currency'  	=> 'Landeswährung',
);
