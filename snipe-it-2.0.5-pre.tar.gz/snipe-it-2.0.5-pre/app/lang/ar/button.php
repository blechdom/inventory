<?php

return array(

    'actions' 	=> 'الإجراءات',
    'add'    	=> 'Add New',
    'cancel'    => 'Cancel',
    'delete'  	=> 'حذف',
    'edit'    	=> 'تعديل',
    'restore' 	=> 'إستعادة',
    'request'   => 'Request',
    'submit'  	=> 'إرسال',
    'upload'    => 'Upload',

);
