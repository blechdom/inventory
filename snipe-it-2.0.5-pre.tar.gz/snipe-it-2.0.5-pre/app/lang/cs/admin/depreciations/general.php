<?php

return array(
    'about_asset_depreciations'  			=> 'O amortizaci majetku',
    'about_depreciations'  					=> 'Můžete nastavit amortizaci majetku pro jeho rovnoměrné odepisování.',
    'asset_depreciations'  					=> 'Amortizace majetku',
    'create_depreciation'  					=> 'Vytvořit amortizaci',
    'depreciation_name'  					=> 'Jméno amortizace',
    'number_of_months'  					=> 'Počet měsíců',
    'update_depreciation'  					=> 'Upravit amortizaci',

);
