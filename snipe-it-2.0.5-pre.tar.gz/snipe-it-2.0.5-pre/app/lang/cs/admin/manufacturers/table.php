<?php

return array(

    'asset_manufacturers'	=> 'Výrobci',
    'create'				=> 'Vytvořit výrobce',
    'id'   					=> 'ID',
    'name'      			=> 'Název Výrobce',
    'update'				=> 'Upravit Výrobce',

);
