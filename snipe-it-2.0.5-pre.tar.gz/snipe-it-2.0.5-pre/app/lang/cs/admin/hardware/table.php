<?php

return array(

    'asset_tag'   	=> 'Označení majetku',
    'asset_model'       => 'Model',
    'book_value'  	=> 'Hodnota',
    'change' 		=> 'Příjem/Výdej',
    'checkout_date' => 'Datum vydání',
    'checkoutto' 	=> 'Vydané',
    'diff' 			=> 'Rozdíl',
    'dl_csv' 		=> 'Stáhnout CSV',
    'eol' 			=> 'Konec životnosti',
    'id'      		=> 'ID',
    'location' 		=> 'Umístění',
    'purchase_cost'	=> 'Cena',
    'purchase_date'	=> 'Zakoupeno',
    'serial'   		=> 'Sériové číslo',
    'status'   		=> 'Stav',
    'title'      	=> 'Majetek ',
    'days_without_acceptance' => 'Days Without Acceptance'

);
