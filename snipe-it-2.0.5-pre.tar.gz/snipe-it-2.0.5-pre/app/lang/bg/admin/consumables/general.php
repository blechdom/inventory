<?php

return array(
    'about_consumables_title' 			=> 'Относно консумативите',
    'about_consumables_text'  			=> 'Консумативите са всички неща, купувани във времето. Например тонер за принтер или хартия.',
    'consumable_name'                  => 'Консуматив',
    'cost'				=> 'Purchase Cost',
    'create'                             => 'Създаване на консуматив',
    'date'					=> 'Purchase Date',
    'order'					=> 'Order Number',
    'remaining' 			             => 'Остава',
    'total' 			                 => 'Oбщо',
    'update'                            => 'Обновяване на консуматив',
);
