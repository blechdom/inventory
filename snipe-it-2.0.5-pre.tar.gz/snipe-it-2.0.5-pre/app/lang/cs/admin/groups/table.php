<?php

return array(

    'id'         => 'ID',
    'name'       => 'Název',
    'users'      => '# z uživatelů',

);
