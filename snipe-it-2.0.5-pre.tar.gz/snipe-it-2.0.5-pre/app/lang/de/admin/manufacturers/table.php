<?php

return array(

    'asset_manufacturers'	=> 'Asset Hersteller',
    'create'				=> 'Hersteller anlegen',
    'id'   					=> 'ID',
    'name'      			=> 'Herstellername',
    'update'				=> 'Hersteller aktualisieren',

);
