<?php

    return [
        'asset_maintenances' => 'Поддръжка на активи',
        'edit'               => 'Редакция на поддръжка на актив',
        'delete'             => 'Изтриване на поддръжка на актив',
        'view'               => 'Преглед на поддръжка на актив',
        'repair'             => 'Ремонт',
        'maintenance'        => 'Поддръжка',
        'upgrade'            => 'Upgrade'
    ];
