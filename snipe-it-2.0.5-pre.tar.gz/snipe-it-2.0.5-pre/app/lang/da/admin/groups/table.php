<?php

return array(

    'id'         => 'Id',
    'name'       => 'Navn',
    'users'      => '# af Brugere',

);
