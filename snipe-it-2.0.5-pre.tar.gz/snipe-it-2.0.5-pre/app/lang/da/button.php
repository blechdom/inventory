<?php

return array(

    'actions' 	=> 'Handlinger',
    'add'    	=> 'Tilføj Ny',
    'cancel'    => 'Annuller',
    'delete'  	=> 'Slet',
    'edit'    	=> 'Rediger',
    'restore' 	=> 'Gendan',
    'request'   => 'Request',
    'submit'  	=> 'Send',
    'upload'    => 'Upload',

);
