<?php

return array(
    'error'   => 'Musíte vybrat alespoň jednu možnost.'
);
